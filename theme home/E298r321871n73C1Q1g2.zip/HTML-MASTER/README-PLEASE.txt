==================NOTE============================
Hi, Thank You Purchase my theme

1. The Walls Real Estate Using Google Fonts CDN You Must Connect Internet 
   If you want to Using This Fonts Or You Can Customize

2. If You want Using Chart JS You Can include file app.js on folder script
   Or You can see Demo Scroll to Bottom with view source on https://wallsproperty.netlify.app/single-detail-v1.html

3. if you finish install npm and want to run master project, and found issue owl-carousel you search folder 
   node_modules/owl.carousel/src/scss/owl.carousel.scss and change import css like this

@import "core";
@import "animate";
@import "autoheight";
@import "lazyload";
// @import 'video';
@import "theme.default";

Don't forget setup this point (3)

4. Theme insya Allah I can Update and Support



Please Give 5 Stars TO support Me, Thank you

Regrads

Mardianto